--create database
use master;
go
if DB_ID (N'lab10') is not null
drop database lab10;
go

-- execute the CREATE DATABASE statement
create database lab10
on ( 
	NAME = lab10_dat, 
	FILENAME = '/Users/olgakotova/Documents/DataBasesLabs/lab10/lab10dat.mdf',
	SIZE = 10, 
	MAXSIZE = UNLIMITED, 
	FILEGROWTH = 5 
	)
log on (
	NAME = lab10_log, 
	FILENAME = '/Users/olgakotova/Documents/DataBasesLabs/lab10/lab10log.ldf',
	SIZE = 5, 
	MAXSIZE = 20, 
	FILEGROWTH = 5 
	);
go

use lab10;
go

if OBJECT_ID(N'Apples') is not null
	drop table Apples;
go

create table Apples (
	person_id int IDENTITY(101,1) PRIMARY KEY,
	person_name varchar(50) not null,
	apples_num INT
    );
go

INSERT INTO Apples(person_name, apples_num)
VALUES ('Vanya', 50),
	   ('Katya', 10),
	   ('Lena', 1),
	   ('Vika', 6)
go