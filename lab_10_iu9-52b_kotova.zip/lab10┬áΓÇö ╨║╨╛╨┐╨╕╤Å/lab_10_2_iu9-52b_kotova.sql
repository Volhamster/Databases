use lab10;
go

-- 4 уровня изоляции:
-- незавершенное чтение   (read uncommited);
-- завершенное чтение       (read commited);
-- воспроизводимое чтение (repeatable read);
-- сериализуемость           (serializable);

-- 1 уровень изоляции:
-- незавершенное чтение   (read uncommited);

BEGIN TRANSACTION;
	SELECT * FROM Apples;
	UPDATE Apples SET apples_num = apples_num * 10 WHERE person_id = 3;
	WAITFOR DELAY '00:00:05';
	ROLLBACK;
	
	SELECT * FROM Apples;
	SELECT * FROM sys.dm_tran_locks;
    --COMMIT TRANSACTION
go

-- 2 уровень изоляции:
-- завершенное чтение       (read commited);

-- BEGIN TRANSACTION;
-- 	SELECT * FROM Apples;
-- 	UPDATE Apples SET apples_num = apples_num * 10 WHERE person_id = 103;
	
-- 	SELECT * FROM Apples;
-- 	SELECT * FROM sys.dm_tran_locks;
-- COMMIT TRANSACTION;
-- go


-- 3 уровень изоляции:
-- воспроизводимое чтение       (Repeatable read);

-- BEGIN TRANSACTION;
-- 	INSERT INTO Apples (person_id,person_name,apples_num) VALUES(107,N'Vasya',74)
-- 	SELECT * FROM sys.dm_tran_locks;
-- 	COMMIT TRANSACTION;
-- go

-- 4 уровень изоляции:
-- сериализуемость        (Serializable);

-- BEGIN TRANSACTION;
-- INSERT INTO Apples (person_id,person_name,apples_num) VALUES(108,N'Nastya',100)
-- SELECT resource_type, resource_subtype, request_mode FROM sys.dm_tran_locks;
-- COMMIT TRANSACTION;
-- go